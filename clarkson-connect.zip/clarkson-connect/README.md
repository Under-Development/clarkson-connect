# clarkson-connect
Walkie-talkie application for Clarkson Students/Staff on smart phones!
