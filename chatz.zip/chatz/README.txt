NETWORK

MANIFEST *******************
REMEMBER TO CHANGE THE MANIFEST PERMISSIONS 



    //objects
    Button btnOnOff, btnDiscover, btnSend;
    ListView listView;
    TextView read_msg_box, ConnectionStatus;
    EditText writeMsg;

    WifiManager wifiManager;
    WifiP2pManager mManager;
    WifiP2pManager.Channel mChannel;

    BroadcastReceiver mReceiver;
    IntentFilter mIntentFilter;

    List<WifiP2pDevice> peers=new ArrayList<WifiP2pDevice>();
    String[] deviceNameArray;
    WifiP2pDevice[] deviceArray;



    static final int MESSAGE_READ=1;

    ServerClass serverClass;
    ClientClass clientClass;
    SendReceive sendReceive;



CLASSES::

public ServerClass extends Thread

private SendReceive extends Thread

public ClientClass extends Thread



MAIN ACTIVITY 

oncreate {

call initialWork() //which holds all initializations 

call exqListner(); //which handles the wifi enable disable button 
}


//for when the app opens and closes 
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mReceiver,mIntentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mReceiver);
    }

//WiFiDirectBroadcastReceiverk.java is self explanatory just add it to com.example.... your main path where you MainActivity is


XML is Relative Layout 

activity_main.xml


